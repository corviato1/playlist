---
name: '🛠 Broken Stream'
about: Report a broken stream
title: 'Fix: xxx'
labels: broken stream
assignees: ''
---

<!-- Please fill out the information in this issue template so that we can
efficiently process your request -->

<!-- IMPORTANT: An issue may contain a request for only one channel, otherwise it will be closed -->

**_Channel Name:_** xxx
**_Broken Link (from playlist):_** xxx
**_Possible Replacement (optional):_** xxx
**_Notes (optional):_** xxx
